﻿using System;
/*
 Nombre: Maria Del Pilar Ceballes Artunduaga
 Grupo:118
 Programa N0. 3
 El Zoológico municipal necesita crear un directorio de animales con
 nombre y país de origen así:
    • Por teclado se debe solicitar la cantidad de animales a registrar
      (ejemplo si digita 5 deberá repetir los pasos siguientes 5 veces)
    • Se requiere captura por teclado de nombre y especie (Ej: León,
      Ruanda / Oso pardo, USA).
    • Se debe luego imprimir el total de animales registrados con su
      nombre y país de origen.
 Metodos utilizados: IngresarDatos, ImprimirDatos
 */

namespace Ejercico3
{
    class Program
    {
        static void Main(string[] args)
        {   
            //Instancia de objetos
            ClasePOO obj1 = new ClasePOO();

            Console.WriteLine("\nDirectorio de animales Zoológico municipal\n");

            //Invocacion de objeto
            obj1.IngresarDatos(); //Ejecuta el metodo para ingresar los datos
            obj1.ImprimirDatos(); //Ejecuta el metodo que imprime los datos
        }
    }
}
