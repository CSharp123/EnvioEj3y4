﻿using System;
using System.Collections.Generic;
using System.Text;
/*
 Nombre: Maria Del Pilar Ceballes Artunduaga
 Grupo:118
 Programa N0. 3
 El Zoológico municipal necesita crear un directorio de animales con
 nombre y país de origen así:
    • Por teclado se debe solicitar la cantidad de animales a registrar
      (ejemplo si digita 5 deberá repetir los pasos siguientes 5 veces)
    • Se requiere captura por teclado de nombre y especie (Ej: León,
      Ruanda / Oso pardo, USA).
    • Se debe luego imprimir el total de animales registrados con su
      nombre y país de origen.
 Metodos utilizados: IngresarDatos, ImprimirDatos
 */

namespace Ejercico3
{
    class ClasePOO
    {
        //Atributos de la clase
        private int CantidadAn; //Tipo entero
        private List<string> Nombre; //Tipo lista cadena de texto 
        private List<string> POrigen; //Tipo lista cadena de texto

        //Metodo constructor
        public ClasePOO()
        {
            CantidadAn = 0;
            Nombre = new List<string>();
            POrigen = new List<string>();
        }

        //Metodo para ingresar los datos
        public void IngresarDatos()
        {
            Console.Write("Cantidad de animales a registrar: ");
            CantidadAn = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("\nIngrese los datos: Nombre, especie y país de orige\n");
           
            for (int i = 0; i < CantidadAn; i++)
            {
                Console.Write("Nombre: ");
                Nombre.Add(Console.ReadLine());

                Console.Write("País de origen: ");
                POrigen.Add(Console.ReadLine());

                Console.WriteLine(" \n");
            }
        }

        //Metodo para imprimir los datos ingresados
        public void ImprimirDatos()
        {
            Console.WriteLine("Animales registrados:\n");

            for (int i = 0; i < CantidadAn; i++)
            {
                Console.WriteLine("{1}, {2}", i + 1, Nombre[i], POrigen[i]);
            }
            Console.WriteLine("\nEl total de animales registrados son: " + CantidadAn);
        }
    }
}
