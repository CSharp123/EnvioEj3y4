﻿using System;
using System.Collections.Generic;
using System.Text;
/*
 Nombre: Maria Del Pilar Ceballes Artunduaga
 Grupo:118
 Programa N0. 4
 En el curso de matemáticas se requiere un programa que calcular el
 área y el perímetro de un círculo así:
    • Se requiere captura por teclado del radio y el diámetro del círculo
      (siendo el radio y el diámetro números flotantes).
    • Se debe calcular e imprimir en consola el valor del área y del
      perímetro del círculo.
NOTA: El área de un círculo es 3.14 * r2. Es decir 3.14 por el radio r al cuadrado.
NOTA: El diámetro de un círculo es 3.14 * d. Es decir 3.14 por el diámetro d.
 Metodos utilizados: setRadio, setDiametro, Area, Perimetro
 */

namespace Ejercicio4
{
    class Circulo
    {
        //Atributos de la clase
        private float Radio;
        private float Diametro;

        //Metodo constructor
        public Circulo()
        {
            Radio = 0;
            Diametro = 0;
        }

        //Metodo para ingresar el radio
        public void setRadio()
        {
            Console.Write("Radío: ");
            Radio = Convert.ToSingle(Console.ReadLine());
        }

        //Metodo para ingresar el diametro
        public void setDiametro()
        {
            Console.Write("Diámetro: ");
            Diametro = Convert.ToSingle(Console.ReadLine());
        }

        //Metodo para calcular el area
        public float Area()
        {
            float AreaC = Convert.ToSingle(Math.PI * Math.Pow(Radio, 2));

            return AreaC;
        }

        //Metodo para calcular el perimetro
        public float Perimetro()
        {
            float Perimetro = Convert.ToSingle(Math.PI * Diametro);

            return Perimetro;
        }
    }
}
